Directory description:
    install   Installation directory
    program   Program directory

Recommend using software：
    1.7-zip     https://www.7-zip.org/
    1.vscode  https://code.visualstudio.com/

Instructions:
    1. Install Python from "Python download"
    2. Use install.bat to install Python packages and clean up redundant files

